<!-- Keep a Changelog guide -> https://keepachangelog.com -->

# Zencoder: Your Mindful AI Coding Agent Changelog

## 2.2.0 - 2025-05-14

### Improvements:

- Added counters to Agent tools tabs

### Fixes:

- Advanced AI tokens plan limits no longer apply if custom Claude key is used for agents
- Automatic reconnection in case websocket connection was lost
- Various UI fixes

## 2.0.0 - 2025-05-08

### New Features:

- Agent Tools: Added a centralized Agent Tools section to manage all tools in one place.
- MCP Library: Introduced a built-in MCP library featuring 100+ of the most useful MCP servers for engineers, ready to enable for your agents.
- Agent Sharing: Admins can now share custom agents with all users in the account.
- Tool Configuration for Custom Agents: Easily configure and save the tools available to custom agents (Zencoder agents use all available tools by default).

### Improvements:

- Custom agents are now synced across all devices and IDEs.
- MCP servers are now installed at the project level by default, simplifying configuration.
- The Unit Tests agent now displays test scenarios more frequently to encourage review before code generation.
- Users can now easily upgrade when hitting usage limits on the free plan.

### Fixes:

- Resolved an issue where opening web links could freeze the plugin UI.
- Fixed compatibility issues with the Execute Shell Command tool in some terminals.
- The Project Info tool is now reliably accessible to agents in all cases.

## 1.28.0 - 2025-04-28

### New Features:

- Now /review is a custom agent you can modify the way it works best for your cases

### Improvements:

- Requirements tool is enabled by default for all users. You can always turn it off in extension settings

### Fixes:

- Small fixes and quality improvements

## 1.26.0 - 2025-04-17

### New Features:

- Coding agent can now run shell commands

### Fixes:

- Shell tool was waiting for several minutes after command completion in some cases

## 1.24.0 - 2025-04-10

### New Features:

- Requirements Tool (Beta) – Now available in settings! When enabled, the agent will ask clarifying questions to better understand your prompt and deliver higher-quality results.
- Local Search Tools – Enhances context retrieval to make responses even more relevant and accurate.

### Improvements:

- File Mentions – Easily add files to the context by referencing them with @ in your prompts.
- Bash tool – improved UX and ability to quickly add command to safe list while running

## 1.22.0 - 2025-04-02

### Improvements:

- Bash tool safe command list, if enabled, applies with to coffee mode and default (with manual changes review) mode
- In coding agent mode, suggestion to create a new chat is now shown if the chat is too long

### Fixes:

- Various stability fixes

## 1.20.0 - 2025-03-27

### Improvements:

- Small UX/UI tweaks — hard to spot, but it feels smoother now

## 1.18.0 - 2025-03-20

### Improvements:

- Accepted changes are automatically saved to files

### Fixes:

- Confusing undo/redo behavior in chat input
- Minor UX/UI fixes

## 1.16.0 - 2025-03-12

### New Features:

- Coffee mode (hands off mode) for our agents - eliminate the need for confirmation on every agent action.
- Configure MCP Servers – Enable seamless integration with Zencoder to support millions of community-built tools.

### Improvements:

- We simplified docstring generation UX and improved generation quality
- Better codebase understanding
- No need to enable coding agent in every chat, now we remember its state for you
- /fix command now uses coding agent for better results
- UI improvements on New chat screen
- Used simple chat for coding tasks? We'll notice that and help to regenrate with Coding agent enabled in a single click
- Coding agent is now even more stable and generates even better code

### Fixes:

- Many small UI fixes
- Occasional issues with filepaths on Windows
- Sometimes `;)` symbols were replaced with emoji in chat

## 1.14.0 - 2025-03-06

### New Features:

- Jira integration allows you to mention Jira tickets to fix/implement directly in chat

### Improvements:

- Custom AI instructions are now supported in coding agent
- We added notification about new plugin version, so you could sooner benefit from all the updates
- Unit tests agent checks syntax and compile errors of generated code
- Unit tests agent now analyzes existing tests to avoid duplication
- New chat button & UI to easily create new chat from any screen of the plugin
- Supported Claude 3.7 in model selection for chat

### Fixes:

- Opt (Alt) + Arrow does not work correctly in chat input
- Zillion of other small and medium sized issues affected quality and stability fixed

## 1.12.0 - 2025-02-26

### New Features:

- New Unit Test agent - generate tests and test scenarios via /unittests in chat or via code lenses
- Custom AI agents in chat - perform custom software development tasks via / (slash) commands

### Improvements:

- Syntax highlighting for code completion by default
- Redesigned diff apply component for agent and Apply All button
- Attachments support for coding agent mode
- Better handling of large repositories and file systems
- Better support for multi-repository projects
- Code completion is not shown for non-code plaintext files

### Fixes:

- Fixed coding agent not generating diffs in followups
- Fixed Cmd/Ctrl + Arrow navigation in chat
- Better error handling and network issue reporting
- Various stability and performance improvements

## 1.10.2 - 2025-02-20

### Fixes:

- Fix the issue related to indexing repositories that contain a large number of files

## 1.10.1 - 2025-02-18

### Fixes:

- Fix the issue with the coding agent not correctly reading directories

## 1.10.0 - 2025-02-17

### Improvements:

- UI to display diffs generated by coding agent
- Code indexing is now faster and more stable
- Depending on agent, now you see agent name in chat

### Fixes:

- Completion suggestion is show when code is pasted in IDE
- Message editing does not work for coding agent chats

## 1.8.1 - 2025-02-10

### Fixes:

- Fix the issue with the repository analysis process getting stuck

## 1.8.0 - 2025-02-06

### New Features:

- Workspace file search for attaching files
- Chat renaming

### Improvements:

- Improved progress visualization for coding agent
- Better autocompletion suggestions for Dart

### Fixes:

- Various UI fixes

## 1.6.4 - 2025-02-01

### Fixes:

- Fixed the issue when coding agent didn't release chat after execution

## 1.6.3 - 2025-01-31

### Improvements:

- Improved error handling

## 1.6.2 - 2025-01-30

### Fixes:

- Fixed the issue with indexing an empty project

## 1.6.1 - 2025-01-30

### Fixes:

- Coding agent did not work with welcome tab opened

## 1.6.0 - 2025-01-29

### New Features:

- Editing of the messages in chat

### Improvements:

- Performance improvements
- New shortcuts for accept/reject of diffs

### Fixes:

- Session logout issues

## 1.4.0 - 2025-01-22

### New Features:

- Coding agent is now available to all users (enable toggle in chat input)

### Fixes:

- Codebase indexing is now faster
- Sign in button sometimes is not visible in the light theme

## 1.2.0 - 2025-01-16

### New Features:

- Coding Agent public beta: fix bugs, develop new features, refactor code with actionable diffs generation

## 1.0.0 - 2025-01-15

### Fixes:

- Logout issues
- Fixed lots of small indexing issues

## 0.11.0 - 2025-01-08

### New Features:

- New editable and intuitive diff viewer for reviewing changes suggested by coding and unit test agents

### Improvements:

- Improved code completion suggestions for Go, Java and Jupyter notebooks
- Slash commands can now be called from code lenses
- Error messages are now way more helpful

### Fixes:

- Corrected repo grokking warnings and errors display
- Quick fix menu now displays familiar standard options first

## 0.9.0 - 2024-12-18

### New Features:

- Easily impact on product quality by reacting with thumb up/down to chat responses and share details if something went wrong

### Improvements:

- Updated UI of signup screen

### Fixes:

- Minor fixes and performance improvements

## 0.7.0 - 2024-12-12

### New Features:

- Review/Explain/Fix commands - quickly
- Users can now provide their own API key and select preferred LLM for chat

### Improvements:

- Improved code completion suggestions for C#
- Error messages are now way more helpful
- Better time display for user messages
- Improved loading state for chat messages

### Fixes:

- Coding agent now properly retrieves files relevant to user’s query
- Sometimes chat lacks context due to incorrect filepaths
- Unnecessary error notifications shown to users
- No way to delete generic codeblocks from input

## 0.5.0 - 2024-12-04

### New Features:

- Indexing is now possible in repos w/o git

### Improvements:

- Code completion context adjustments
- Better code completion for C and C++
- Show message time in chat
- New chat input UX, better context selection and visibility
- Updated AI instructions UX + change scope to global
- Show references in response messages

### Fixes:

- Do not show odd spaces in sent messages
- Do not show completion errors to the user

## 0.3.0 - 2024-11-20

### New Features:

- Added confirmation to delete chat

### Improvements:

- Improved UI here and there to make zencoder even more appealing
- Improved repo indexing logic, now it’s more stable and fast
- Improved new version notification

### Fixes:

- Fixed docstring generation issue
- Fixed annoying Auth issue, that logged some users out too often

## 0.2.0 - 2024-11-15

## 0.1.0 - 2024-10-25
